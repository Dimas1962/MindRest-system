# docs/onboarding_guide.md
